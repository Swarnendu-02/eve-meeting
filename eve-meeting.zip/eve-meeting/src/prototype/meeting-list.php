<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <?php include_once("includes/pagesources.php"); ?>
</head>

<body>

    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full" data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">
        <?php include_once("includes/header.php"); ?>
        <?php include_once("includes/left-bar.php"); ?>
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 align-self-center">
                        <h3 class="page-title text-truncate text-dark font-weight-medium mb-1">Meeting List</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                    <li class="breadcrumb-item text-muted active" aria-current="page">Dashboard</li>
                                    <li class="breadcrumb-item text-muted" aria-current="page">Meeting</li>
                                    <li class="breadcrumb-item text-muted" aria-current="page">Meeting List</li>
                                </ol>
                            </nav>
                        </div>
                    </div>

                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div id="accordion" class="custom-accordion mb-4">

                                    <div class="card mb-0">
                                        <div class="card-header d-flex align-items-center" id="headingOne">
                                            <h5 class="m-0">
                                                <a class="custom-accordion-title d-block pt-2 pb-2 d-flex align-items-center" data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                    <div class="meeting-date-time">
                                                        <p>Aug</p>
                                                        <h3>12</he>
                                                    </div>
                                                    <div class="meeting-title-box">
                                                        <p class="meeting-title">Meeting Title <span class="badge badge-pill badge-primary ml-2 py-2 px-3">MOM</span></p>
                                                        <p class="meeting-place">fakjvdskjnvsakjv</p>
                                                        <p class="meeting-time">18:57 - 20:00</p>
                                                    </div>


                                                </a>

                                            </h5>
                                            <div class="ml-auto">
                                                <div class="dropdown sub-dropdown">
                                                    <button class="btn btn-link text-muted dropdown-toggle" type="button" id="dd1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i data-feather="more-vertical"></i>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd1">
                                                        <a class="dropdown-item" href="#">Insert</a>
                                                        <a class="dropdown-item" href="#">Update</a>
                                                        <a class="dropdown-item" href="#">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapseOne" class="collapse show meeting-detail-box" aria-labelledby="headingOne" data-parent="#accordion">
                                            <div class="card-body">
                                                <div>
                                                    <label>Details:</label>
                                                    <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry
                                                        richardson ad squid. 3 wolf moon officia aute,
                                                        non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                        eiusmod. Brunch 3 wolf moon
                                                        tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda
                                                        shoreditch et. Nihil
                                                        anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente
                                                        ea proident. Ad vegan
                                                        excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw
                                                        denim aesthetic synth nesciunt
                                                        you probably haven't heard of them accusamus labore sustainable VHS.</p>
                                                </div>
                                                <div>
                                                    <label>Members:</label>
                                                    <div class="row mt-2">
                                                        <div class="col-md-3 py-2">
                                                           
                                                            <div class="d-flex no-block align-items-center position-relative">
                                                                <div class="mr-3"><img src="../assets/images/users/widget-table-pic1.jpg" alt="user" class="rounded-circle" width="45" height="45"></div>
                                                                <div class="">
                                                                    <h5 class="text-dark mb-0 font-16 font-weight-medium">Hanna
                                                                        Gover</h5>
                                                                    <span class="text-muted font-14">hgover@gmail.com</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3 py-2">
                                                            <div class="d-flex no-block align-items-center position-relative">
                                                                <div class="mr-3"><img src="../assets/images/users/widget-table-pic1.jpg" alt="user" class="rounded-circle" width="45" height="45"></div>
                                                                <div class="">
                                                                    <h5 class="text-dark mb-0 font-16 font-weight-medium">Hanna
                                                                        Gover</h5>
                                                                    <span class="text-muted font-14">hgover@gmail.com</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3 py-2">
                                                            <div class="d-flex no-block align-items-center position-relative">
                                                                <div class="mr-3"><img src="../assets/images/users/widget-table-pic1.jpg" alt="user" class="rounded-circle" width="45" height="45"></div>
                                                                <div class="">
                                                                    <h5 class="text-dark mb-0 font-16 font-weight-medium">Hanna
                                                                        Gover</h5>
                                                                    <span class="text-muted font-14">hgover@gmail.com</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3 py-2">
                                                            <div class="d-flex no-block align-items-center position-relative">
                                                                <div class="mr-3"><img src="../assets/images/users/widget-table-pic1.jpg" alt="user" class="rounded-circle" width="45" height="45"></div>
                                                                <div class="">
                                                                    <h5 class="text-dark mb-0 font-16 font-weight-medium">Hanna
                                                                        Gover</h5>
                                                                    <span class="text-muted font-14">hgover@gmail.com</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> <!-- end card-->
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <?php include_once("includes/footer.php"); ?>
        </div>
    </div>
    <?php include_once("includes/fot-js.php"); ?>
</body>

</html>