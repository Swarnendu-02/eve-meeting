<footer class="footer text-center text-muted">
                All Rights Reserved by EVE. Designed and Developed by <a
                    href="#">ENCODERS</a>.
            </footer>