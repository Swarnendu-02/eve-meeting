<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <?php include_once("includes/pagesources.php"); ?>
</head>

<body>

    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full" data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">
        <?php include_once("includes/header.php"); ?>
        <?php include_once("includes/left-bar.php"); ?>
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 align-self-center">
                        <h3 class="page-title text-truncate text-dark font-weight-medium mb-1">New Meeting</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                    <li class="breadcrumb-item text-muted active" aria-current="page">Dashboard</li>
                                    <li class="breadcrumb-item text-muted" aria-current="page">New Meeting</li>
                                </ol>
                            </nav>
                        </div>
                    </div>

                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Schedule Meeting</h4>
                                <form action="#">
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Title</label>
                                                    <input type="text" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Location</label>
                                                    <select class="form-control" id="exampleFormControlSelect1">
                                                        <option>Room 1</option>
                                                        <option>Room 2</option>
                                                        <option>Room 3</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Date</label>
                                                    <input type="date" class="form-control" value="2018-05-13">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Start</label>
                                                    <input type="time" class="form-control" value="22:33:00">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>End</label>
                                                    <input type="time" class="form-control" value="22:33:00">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Details</label>
                                                    <textarea class="form-control" rows="8"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Add Staff</label>
                                                    <div class="row mt-2">
                                                        <div class="col-md-3 py-2">
                                                            <label class="container">One
                                                                <input type="checkbox" checked="checked">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                            <div class="d-flex no-block align-items-center position-relative">
                                                                <div class="mr-3"><img src="../assets/images/users/widget-table-pic1.jpg" alt="user" class="rounded-circle" width="45" height="45"></div>
                                                                <div class="">
                                                                    <h5 class="text-dark mb-0 font-16 font-weight-medium">Hanna
                                                                        Gover</h5>
                                                                    <span class="text-muted font-14">hgover@gmail.com</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3 py-2">
                                                            <div class="d-flex no-block align-items-center position-relative">
                                                                <div class="mr-3"><img src="../assets/images/users/widget-table-pic1.jpg" alt="user" class="rounded-circle" width="45" height="45"></div>
                                                                <div class="">
                                                                    <h5 class="text-dark mb-0 font-16 font-weight-medium">Hanna
                                                                        Gover</h5>
                                                                    <span class="text-muted font-14">hgover@gmail.com</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3 py-2">
                                                            <div class="d-flex no-block align-items-center position-relative">
                                                                <div class="mr-3"><img src="../assets/images/users/widget-table-pic1.jpg" alt="user" class="rounded-circle" width="45" height="45"></div>
                                                                <div class="">
                                                                    <h5 class="text-dark mb-0 font-16 font-weight-medium">Hanna
                                                                        Gover</h5>
                                                                    <span class="text-muted font-14">hgover@gmail.com</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3 py-2">
                                                            <div class="d-flex no-block align-items-center position-relative">
                                                                <div class="mr-3"><img src="../assets/images/users/widget-table-pic1.jpg" alt="user" class="rounded-circle" width="45" height="45"></div>
                                                                <div class="">
                                                                    <h5 class="text-dark mb-0 font-16 font-weight-medium">Hanna
                                                                        Gover</h5>
                                                                    <span class="text-muted font-14">hgover@gmail.com</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-actions mt-4">
                                        <div class="text-right">
                                            <button type="submit" class="btn btn-info">Submit</button>
                                            <button type="reset" class="btn btn-dark">Reset</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <?php include_once("includes/footer.php"); ?>
        </div>
    </div>
    <?php include_once("includes/fot-js.php"); ?>
</body>

</html>